"""PDF report placeholder."""
