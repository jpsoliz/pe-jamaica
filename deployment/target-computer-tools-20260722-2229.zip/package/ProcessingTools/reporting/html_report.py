"""HTML report placeholder."""
