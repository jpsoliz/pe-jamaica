"""JSON report placeholder."""
