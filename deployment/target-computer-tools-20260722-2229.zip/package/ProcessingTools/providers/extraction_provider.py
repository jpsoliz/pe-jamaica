"""Extraction provider interface placeholder."""
