"""OCR extraction provider placeholder."""
