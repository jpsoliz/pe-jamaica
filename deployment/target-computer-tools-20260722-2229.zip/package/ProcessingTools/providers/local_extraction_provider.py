"""Local extraction provider placeholder."""
