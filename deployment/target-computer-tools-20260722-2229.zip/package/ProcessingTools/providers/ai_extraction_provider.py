"""AI extraction provider placeholder."""
